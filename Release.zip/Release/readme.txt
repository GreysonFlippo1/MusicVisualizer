DOWNLOAD FROM CHROME WEB STORE:
https://chrome.google.com/webstore/detail/music-visualizer-for-goog/ofhohcappnjhojpboeamfijglinngdnb?hl=en

Feel free to download the source files from here and change around what you like and run the extension as a developer extension.
All dependent files for the extension to run are present. 

Current Relase Version: 10.0

developer Notes:
things to change-
    x start using github
    x menu button change in functionality and design (too annyoing espically in youtube)
    x audio source finder
    x bug that makes the sound high pitched after inactivity
    x optimize performance for less powerful devices
    x add a notification when the visualizer has found an audio souce and show it's key binding to enable it
    x make less dependent on knowing which website the extension is loaded on top of
    x add a space where the keybindings can be viewed by the user
    x look into storage for saving settings https://developer.chrome.com/extensions/storage
    > find optimizations
    > better organization
    > optimize ui for small displays better 
    - add a test website to run tests quicker
    - make some debugging functions
